import { createContext } from "react";

export const ProductesContext = createContext();